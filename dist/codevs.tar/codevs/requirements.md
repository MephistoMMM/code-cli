docopt >= 0.6.1
sh >= 1.11
