from . import logInit

logInit.checkOldLogger()
logInit.setupLogger()
